package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;


@SpringBootApplication
public class GatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(GatewayApplication.class, args);
    }


    /**
     * Programmatic routes (mirror of application.yml). Keep either this or the YAML section below.
     * If you prefer YAML-only configuration, remove this bean.
     */
    @Bean
    public RouteLocator customRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
                // Route to Authentication A
                .route("auth-a", r -> r
                        .path("/auth/a/**")
                        .filters(f -> f.stripPrefix(2))
                        .uri("${AUTH_A_URL:http://auth-a.default.svc.cluster.local}"))
                // Route to Authentication B
                .route("auth-b", r -> r
                        .path("/auth/b/**")
                        .filters(f -> f.stripPrefix(2))
                        .uri("${AUTH_B_URL:http://auth-b.default.svc.cluster.local}"))
                // Catch-all for /auth/* that doesn’t match
                .route("auth-not-found", r -> r
                        .path("/auth/**")
                        .filters(f -> f.setStatus(HttpStatus.NOT_FOUND))
                        .uri("no://op"))
                .build();
    }
}
